//
//  ChatViewController.h
//  Univer
//
//  Created by 백 운천 on 12. 10. 4..
//  Copyright (c) 2012년 백 운천. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HPGrowingTextView.h"


@interface ChatViewController : UIViewController <HPGrowingTextViewDelegate>
{
    NSUserDefaults *userDefaults;
    
    UIWebView *webView;
    NSString *to_id;
    NSString *to_nick;
    NSString *roomName;
    NSString *is_chatRoom;
    NSString *my_id;
    NSString *chatRoom_id;
    NSString *seller;
    
    UIView *containerView;

    HPGrowingTextView *textView;
    
    NSDictionary *dic;

    
    UIAlertView *alert;
    UIActivityIndicatorView *spiner;

    
    int kinds;
}

@property (nonatomic, strong) IBOutlet UIWebView *webView;
@property (strong) NSDictionary *dic;
@property (strong) NSString *to_id;
@property (strong) NSString *to_nick;
@property int kinds;

@property (nonatomic, strong) UIAlertView *alert;
@property (nonatomic, strong) UIActivityIndicatorView *spiner;


@end
