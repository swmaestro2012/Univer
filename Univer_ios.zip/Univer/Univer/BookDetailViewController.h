//
//  BookDetailViewController.h
//  Univer
//
//  Created by 백 운천 on 12. 10. 4..
//  Copyright (c) 2012년 백 운천. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TouchXML.h"

@interface BookDetailViewController : UIViewController
{
    UITableView *bookTableView;
    NSString *seller_id;
    NSString *seller_nick;
    NSString *entriesAddress;
    UIImage *image;
    NSDictionary *dic;
    
    NSMutableArray *entriesArray;
}

- (void)entriesRSSFeed:(NSString *)entriesAddress;


- (void)photo_btn:(id)sender;
- (void)chat_btn:(id)sender;


@property (nonatomic, retain) NSDictionary *dic;
@property (nonatomic, retain) IBOutlet UITableView *bookTableView;
@end
