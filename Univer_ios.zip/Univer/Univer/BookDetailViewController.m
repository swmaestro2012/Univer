//
//  BookDetailViewController.m
//  Univer
//
//  Created by 백 운천 on 12. 10. 4..
//  Copyright (c) 2012년 백 운천. All rights reserved.
//

#import "BookDetailViewController.h"
#import "AsyncImageView.h"
#import "ChatViewController.h"
#import "PhotoDetailViewController.h"


#define CELL_CONTENT_WIDTH 320.0f
#define CELL_CONTENT_MARGIN 10.0f


#define FEED_BOOKS                            @"http://54.248.233.34/feeds/books/"
#define IMAGE_BASE                            @"http://54.248.233.34"



@implementation BookDetailViewController
@synthesize bookTableView;
@synthesize dic;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        UIView *leftView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 31, 44)];
        UIButton *btn1 = [UIButton buttonWithType:UIButtonTypeCustom];
        btn1.frame =CGRectMake(0, 7, 31, 31);
        [btn1 setBackgroundImage:[UIImage imageNamed:@"cm_back_selected.png"] forState:UIControlStateHighlighted];
        [btn1 setBackgroundImage:[UIImage imageNamed:@"cm_back_unselected.png"] forState:UIControlStateNormal];
        [btn1 addTarget:self action:@selector(backBtn:) forControlEvents:UIControlEventTouchUpInside];
        [leftView addSubview:btn1];
        UIBarButtonItem *leftItem = [[UIBarButtonItem alloc] initWithCustomView:leftView];
        self.navigationItem.leftBarButtonItem = leftItem;

        
    }
    return self;
}

- (void)backBtn:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [self.navigationController.navigationBar setBackgroundImage:[UIImage imageNamed:@"cm_navigation_background_2.jpg"] forBarMetrics:UIBarMetricsDefault];
    
    UIImage *repeatingImage = [UIImage imageNamed:@"cm_background_pattern.png"];
    self.view.backgroundColor = [UIColor colorWithPatternImage:repeatingImage];



    
    [super viewDidLoad];
    self.title = [dic objectForKey:@"title"];
    entriesArray = [[NSMutableArray alloc] initWithCapacity:10];
    
    [NSThread detachNewThreadSelector:@selector(start_rss) toTarget:self withObject:nil];
    
    // Do any additional setup after loading the view from its nib.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    
    self.bookTableView = nil;
    self.dic = nil;
    
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (IBAction)back_btn:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}
#pragma mark - TableView cycle


- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 2;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    if (section == 0)
        return @"";
    else
        return @"판매자의 다른상품 보기";
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (section == 0)
        return 3;
    else
        return [entriesArray count];
    
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    UITableViewCell *cell = nil;
    UITableViewCell *cell1 = nil;
    UITableViewCell *cell2 = nil;
    UITableViewCell *cell4 = nil;
    
    static NSString *CellIdentifier = @"Cell";
    static NSString *CellIdentifier1 = @"Cell1";
    static NSString *CellIdentifier2 = @"Cell2";
    static NSString *CellIdentifier4 = @"Cell4";
    
    cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    cell1 = [tableView dequeueReusableCellWithIdentifier:CellIdentifier1];
    cell2 = [tableView dequeueReusableCellWithIdentifier:CellIdentifier2];
    cell4 = [tableView dequeueReusableCellWithIdentifier:CellIdentifier4];
    
    UIImageView *cellBackgroundView;
    UIImageView *backgroundView;
    UILabel *titleLabel;
    UILabel *categoryLabel;
    UILabel *priceLabel;
    UIImageView *parcelImageView;
    UIImageView *meetImageView;
    UIImageView *noImageView;
    AsyncImageView *asyncImageView;

    
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        cell.backgroundColor = [UIColor whiteColor];
    }
    if (cell1 == nil) {
        cell1 = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier1];
    }	
    if (cell2 == nil) {
        cell2 = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier2];
        cell2.backgroundColor = [UIColor whiteColor];
    }
    if (cell4 == nil) {
        cell4 = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier4];
        cell4.backgroundColor = [UIColor whiteColor];
//        cellBackgroundView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 320, 80)];
//        cellBackgroundView.image = [UIImage imageNamed:@"bk_normal.jpg"];
        
        backgroundView = [[UIImageView alloc] initWithFrame:CGRectMake(144, 0, 166, 80)];
        
        noImageView = [[UIImageView alloc] initWithFrame:CGRectMake(16, 8, 60, 60)];
        noImageView.image = [UIImage imageNamed:@"noImage.png"];
        
        asyncImageView = [[AsyncImageView alloc] initWithFrame:CGRectMake(16, 8, 60, 60)];
        
        titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(87, 7, 220, 21)];
        titleLabel.backgroundColor = [UIColor clearColor];
        titleLabel.font = [UIFont fontWithName:@"NanumGothicBold" size:15];
        
        
        categoryLabel = [[UILabel alloc] initWithFrame:CGRectMake(87, 27, 240, 21)];
        categoryLabel.backgroundColor = [UIColor clearColor];
        categoryLabel.font = [UIFont fontWithName:@"NanumGothicBold" size:14];
        categoryLabel.textColor = [UIColor grayColor];
        
        priceLabel = [[UILabel alloc] initWithFrame:CGRectMake(205, 55, 100, 21)];
        priceLabel.backgroundColor = [UIColor clearColor];
        priceLabel.font = [UIFont fontWithName:@"NanumGothicBold" size:14];
        priceLabel.textColor = [UIColor cyanColor];
        
        parcelImageView = [[UIImageView alloc] initWithFrame:CGRectMake(87, 55, 44, 20)];
        meetImageView = [[UIImageView alloc] initWithFrame:CGRectMake(142, 55, 44, 20)];
        
        [cell4 addSubview:cellBackgroundView];
        
        [cell4 addSubview:titleLabel];
        [cell4 addSubview:categoryLabel];
        [cell4 addSubview:priceLabel];
        [cell4 addSubview:parcelImageView];
        [cell4 addSubview:meetImageView];

    }
    
    if (indexPath.section == 0) {
        UILabel *label;
        if (indexPath.row == 0) {
            UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(25, 10, 250, 40)];
            titleLabel.text = [dic objectForKey:@"title"];
            titleLabel.lineBreakMode = UILineBreakModeTailTruncation;
            titleLabel.numberOfLines = 0;

            titleLabel.backgroundColor = [UIColor clearColor];
            titleLabel.font = [UIFont fontWithName:@"NanumGothicBold" size:15];

            [cell addSubview:titleLabel];
            
            
            UIButton *image_btn = [UIButton buttonWithType:UIButtonTypeCustom];
            CGRect frame = CGRectMake(25, 55, 60, 60);
            
            image_btn.frame = frame;
            [image_btn addTarget:self action:@selector(photo_btn:) forControlEvents:UIControlEventTouchUpInside];
            
            if ([[dic objectForKey:@"thumbnail"] isEqualToString:@""]) {
                UIImageView *noImageView = [[UIImageView alloc] initWithFrame:frame];
                noImageView.image = [UIImage imageNamed:@"noimage.png"];
                [cell addSubview:noImageView];
            }else{
                AsyncImageView* asyncImage = [[AsyncImageView alloc] initWithFrame:frame];
                asyncImage.tag = 999;
                
                NSString *url_string = [IMAGE_BASE stringByAppendingString:[dic objectForKey:@"thumbnail"]];
                NSURL *aURL = [NSURL URLWithString:url_string];
                [asyncImage loadImageFromURL:aURL];
                [cell addSubview:asyncImage];
                [cell addSubview:image_btn];
            }
            
            UILabel *originalLabel = [[UILabel alloc] initWithFrame:CGRectMake(92, 60, 100, 20)];
            originalLabel.text = [NSString stringWithFormat:@"%@원", [dic objectForKey:@"original_price"]];
            originalLabel.backgroundColor = [UIColor clearColor];
            originalLabel.font = [UIFont fontWithName:@"NanumGothic" size:13];
            originalLabel.textAlignment = UITextAlignmentLeft;

            [cell addSubview:originalLabel];
            
            UILabel *discountLabel = [[UILabel alloc] initWithFrame:CGRectMake(152, 60, 100, 20)];
            discountLabel.text = [NSString stringWithFormat:@"%@원", [dic objectForKey:@"discount_price"]];
            discountLabel.backgroundColor = [UIColor clearColor];
            discountLabel.textAlignment = UITextAlignmentLeft;

            discountLabel.font = [UIFont fontWithName:@"NanumGothicBold" size:16];
            discountLabel.textColor = [UIColor cyanColor];
            
            [cell addSubview:discountLabel];
            
            
            UIButton *chat_btn = [UIButton buttonWithType:UIButtonTypeCustom];
            chat_btn.frame = CGRectMake(240, 55, 60, 60);
            [chat_btn setImage:[UIImage imageNamed:@"bk_dt_talk_unselected.png"] forState:UIControlStateNormal];
            [chat_btn setImage:[UIImage imageNamed:@"bk_dt_talk_selected.png"] forState:UIControlStateHighlighted];
            [chat_btn addTarget:self action:@selector(chat_btn:) forControlEvents:UIControlEventTouchUpInside];
            [cell addSubview:chat_btn];
            
            
            UIImageView *parcelImageView = [[UIImageView alloc] initWithFrame:CGRectMake(92, 95, 44, 20)];
            
            UIImageView *meetImageView = [[UIImageView alloc] initWithFrame:CGRectMake(147, 95, 44, 20)];

            if ([[dic objectForKey:@"parcel"] isEqualToString:@"0"])
                parcelImageView.image = [UIImage imageNamed:@"bk_parcel_false.png"];
            else
                parcelImageView.image = [UIImage imageNamed:@"bk_parcel_true.png"];
            
            if ([[dic objectForKey:@"meet"] isEqualToString:@"0"])
                meetImageView.image = [UIImage imageNamed:@"bk_meet_false.png"];
            else
                meetImageView.image = [UIImage imageNamed:@"bk_meet_true.png"];

            [cell addSubview:parcelImageView];
            [cell addSubview:meetImageView];
            
            return cell;
            
        }else if (indexPath.row ==1){
            UILabel *publisherLabel = [[UILabel alloc] initWithFrame:CGRectMake(30, 17, 50, 20)];
            publisherLabel.font = [UIFont fontWithName:@"NanumGothicBold" size:15];
            publisherLabel.text = @"출판사";
            publisherLabel.backgroundColor = [UIColor clearColor];
            [cell1 addSubview:publisherLabel];
            
            UILabel *publisher = [[UILabel alloc] initWithFrame:CGRectMake(100, 17, 200, 20)];
            publisher.font = [UIFont fontWithName:@"NanumGothic" size:15];
            publisherLabel.textAlignment = UITextAlignmentLeft;
            publisher.text = [dic objectForKey:@"publisher"];
            publisher.backgroundColor = [UIColor clearColor];
            [cell1 addSubview:publisher];
            
            
            
            UILabel *authorLabel = [[UILabel alloc] initWithFrame:CGRectMake(30, 40, 50, 20)];
            authorLabel.backgroundColor = [UIColor clearColor];
            authorLabel.font = [UIFont fontWithName:@"NanumGothicBold" size:15];
            authorLabel.text = @"저  자";
            [cell1 addSubview:authorLabel];
            
            UILabel *author = [[UILabel alloc] initWithFrame:CGRectMake(100, 40, 200, 20)];
            author.backgroundColor = [UIColor clearColor];
            author.font = [UIFont fontWithName:@"NanumGothic" size:15];
            author.text =[dic objectForKey:@"book_author"];
            [cell1 addSubview:author];
            
            
            UILabel *publishedLabel = [[UILabel alloc] initWithFrame:CGRectMake(30, 63, 50, 20)];
            publishedLabel.backgroundColor = [UIColor clearColor];
            publishedLabel.font = [UIFont fontWithName:@"NanumGothicBold" size:15];
            publishedLabel.text = @"발행일";
            [cell1 addSubview:publishedLabel];

            UILabel *published = [[UILabel alloc] initWithFrame:CGRectMake(100, 63, 200, 20)];
            published.backgroundColor = [UIColor clearColor];
            published.font = [UIFont fontWithName:@"NanumGothic" size:15];
            published.text = [dic objectForKey:@"published"];
            [cell1 addSubview:published];
            
            return cell1;
            
            

        }else if (indexPath.row ==2){
                
            UILabel *contentLabel = [[UILabel alloc] initWithFrame:CGRectMake(30, 17, 260, 30)];
            contentLabel.lineBreakMode = UILineBreakModeTailTruncation;
            contentLabel.numberOfLines = 0;
            contentLabel.backgroundColor = [UIColor clearColor];
            contentLabel.font = [UIFont fontWithName:@"NanumGothicBold" size:15];
            contentLabel.text = [dic objectForKey:@"description"];
            [cell2 addSubview:contentLabel];

            return cell2;
            }
    }else{
        NSDictionary *dic_ = [entriesArray objectAtIndex:indexPath.row];
        
        
        titleLabel.text = [dic_ objectForKey:@"title"];
        
        NSString *categoryString = [[dic_ objectForKey:@"region"] stringByAppendingFormat:@" / %@ / %@", [dic_ objectForKey:@"university"], [dic_ objectForKey:@"college"]];
        categoryLabel.text = categoryString;
        
        priceLabel.text = [NSString stringWithFormat:@"%@원", [dic_ objectForKey:@"discount_price"]];
        
        
        if ([[dic_ objectForKey:@"parcel"] isEqualToString:@"0"])
            parcelImageView.image = [UIImage imageNamed:@"bk_parcel_false.png"];
        else
            parcelImageView.image = [UIImage imageNamed:@"bk_parcel_true.png"];
        
        if ([[dic_ objectForKey:@"meet"] isEqualToString:@"0"])
            meetImageView.image = [UIImage imageNamed:@"bk_meet_false.png"];
        else
            meetImageView.image = [UIImage imageNamed:@"bk_meet_true.png"];
        
    	
        if ([[dic_ objectForKey:@"thumbnail"] isEqualToString:@""]) {
            [cell4 addSubview:noImageView];
        }else{
            NSString *url_string = [IMAGE_BASE stringByAppendingString:[dic_ objectForKey:@"thumbnail"]];
            NSURL *aURL = [NSURL URLWithString:url_string];
            [asyncImageView loadImageFromURL:aURL];
            [cell4 addSubview:asyncImageView];
        }
        
        
        int sale = [[dic_ objectForKey:@"sale"] intValue];
        
        if(sale == 2){
            backgroundView.image = [UIImage imageNamed:@"bk_reserved.png"];
            [cell4 addSubview:backgroundView];
        }else if(sale == 3){
            backgroundView.image = [UIImage imageNamed:@"bk_soldout.png"];
            [cell4 addSubview:backgroundView];
        }
        
        UILabel *la = [[UILabel alloc] initWithFrame:CGRectMake(170, 1, 60, 20)];
        la.text = [NSString stringWithFormat:@"%d번", indexPath.row];
        //    [cell add Subview:la];
        return cell4;
    }
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0) {
        if (indexPath.row == 0)
            return 125;
        else if (indexPath.row == 1) {
            NSString *text = [dic objectForKey:@"title"];
            CGSize constraint = CGSizeMake(CELL_CONTENT_WIDTH - (CELL_CONTENT_MARGIN * 2), 20000.0f);
            CGSize size = [text sizeWithFont:[UIFont systemFontOfSize:20.0f] constrainedToSize:constraint lineBreakMode:UILineBreakModeWordWrap];
            CGFloat height = MAX(size.height, 44.0f);
//            return height + (CELL_CONTENT_MARGIN * 2)-20 +30;
            return 105;
        }else if (indexPath.row == 2){
            NSString *text = [dic objectForKey:@"title"];
            CGSize constraint = CGSizeMake(CELL_CONTENT_WIDTH - (CELL_CONTENT_MARGIN * 2), 20000.0f);
            CGSize size = [text sizeWithFont:[UIFont systemFontOfSize:20.0f] constrainedToSize:constraint lineBreakMode:UILineBreakModeWordWrap];
            CGFloat height = MAX(size.height, 44.0f);
            return height + (CELL_CONTENT_MARGIN * 2)-20 +30;

        }else if (indexPath.row == 3){
            NSString *text = [dic objectForKey:@"description"];
            CGSize constraint = CGSizeMake(CELL_CONTENT_WIDTH - (CELL_CONTENT_MARGIN * 2), 20000.0f);
            CGSize size = [text sizeWithFont:[UIFont systemFontOfSize:17.0f] constrainedToSize:constraint lineBreakMode:UILineBreakModeWordWrap];
            CGFloat height = MAX(size.height, 44.0f);
            return height + (CELL_CONTENT_MARGIN * 2) + 25;
        }
    }
    return 80;
}

#pragma mark - Detail Button

- (void)photo_btn:(id)sender
{
    PhotoDetailViewController *photoDetailView = [[PhotoDetailViewController alloc] initWithNibName:@"PhotoDetailViewController" bundle:nil];
    photoDetailView.thumbnail = image;
    photoDetailView.image_url = [dic objectForKey:@"image"];
    [self.navigationController pushViewController:photoDetailView animated:YES];
}

- (void)chat_btn:(id)sender
{

    ChatViewController *chatView = [[ChatViewController alloc] initWithNibName:@"ChatViewController" bundle:nil];
    chatView.hidesBottomBarWhenPushed = YES;
    
    NSLog(@"%@", dic);
    
    
    chatView.to_id = [dic objectForKey:@"seller_id"];
    chatView.to_nick = [dic objectForKey:@"seller_nick"];
    chatView.kinds = 1;
    
    NSLog(@"id %@ nick %@", [dic objectForKey:@"seller_id"], [dic objectForKey:@"seller_nick"]);
    
    [self.navigationController pushViewController:chatView animated:YES];
    
    
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSLog(@"selected");
    if (indexPath.section == 1) {
        self.dic = [entriesArray objectAtIndex:indexPath.row];
        [self.bookTableView reloadData];
        [self.bookTableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0] atScrollPosition:UITableViewScrollPositionNone animated:YES];
    }
}

#pragma mark - RSSFeed

- (void)entriesRSSFeed:(NSString *)address
{
	[entriesArray removeAllObjects];
    
    NSURL *url = [NSURL URLWithString:address];
	
	NSError *error = nil;
    CXMLDocument *rssParser = [[CXMLDocument alloc] initWithContentsOfURL:url options:0 error:&error];
    
    if (error) {
        
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"판매자의 다른물품 보기" message:@"네트워크상태를 확인하세요" delegate:self cancelButtonTitle:@"확인" otherButtonTitles:nil];
        [alertView show];
    }
    
    
    NSArray *resultNodes = NULL;
    
    resultNodes = [rssParser nodesForXPath:@"//item" error:nil];
    for (CXMLElement *resultElement in resultNodes) {
        NSMutableDictionary *newsItem = [[NSMutableDictionary alloc] init];
        int counter;
        for(counter = 0; counter < [resultElement childCount]; counter++) {
            [newsItem setObject:[[resultElement childAtIndex:counter] stringValue] forKey:[[resultElement childAtIndex:counter] name]];
        }
        [entriesArray addObject:[newsItem copy]];
    }
}

#pragma mark Autoreleasepool rss

- (void)start_rss
{
    @autoreleasepool {
        entriesAddress = [FEED_BOOKS stringByAppendingFormat:@"search=0&sale=2&category=6&id=%@&page=1/", [dic objectForKey:@"seller_id"]];
        NSLog(@"%@", entriesAddress);
        [self entriesRSSFeed:entriesAddress];
        [self.bookTableView reloadData];
        
    }
}




@end
