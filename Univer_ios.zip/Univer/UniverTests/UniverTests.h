//
//  UniverTests.h
//  UniverTests
//
//  Created by 백 운천 on 12. 10. 3..
//  Copyright (c) 2012년 백 운천. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface UniverTests : SenTestCase

@end
